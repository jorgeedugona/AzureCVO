#
# create/modify qos-policy-group minimum iops setting
# 	for group of volumes
#
# Example for setting minimum iops on all volumes beginning with "good_vols" to 10k iops:
#	./set_qos.sh good_vols 10000
#

#
# passwordless ssh needs to be configured
#
cluster="xx.xx.xx.xx"
user="admin"
vserver="vServerName"

# pattern match on beginning of volume name
pattern=$1

# specify integer number
min_iops=$2

for i in `ssh -l $user $cluster "rows 0\;vol show -volume $pattern* -fields volume" | grep $pattern | cut -d' ' -f2`
do
	echo $i
	ssh -l $user $cluster "qos policy-group create -policy-group $i -vserver $vserver -min-throughput ${min_iops}iops"
	ssh -l $user $cluster "qos policy-group modify -policy-group $i -min-throughput ${min_iops}iops"
	ssh -l $user $cluster "vol modify -volume $i -qos-policy-group $i"
done
