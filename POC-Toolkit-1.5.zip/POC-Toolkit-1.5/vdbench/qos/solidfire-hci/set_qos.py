#!/usr/bin/python
# vim: tabstop=4 shiftwidth=4 softtabstop=4
#
#
#
# Python script to set QOS values for volumes that match -p pattern
# 
# You must supply a json file for the cluster information
#
#  
#  cat prod.json
#  {
#  "mvip": "10.61.115.30",
#          "mip": "",
#  "svip": "10.61.115.40",
#          "sip": "",
#  "login": "admin",
#  "password": "xxxxxx",
#          "node_list":[]
#  }
#
#
# Example of how the script is called to adjust qos settings on all volumes matching the pattern "good":
#
#   ./set_qos.py -C prod.json -p good -m 2000 -x 3000 -b 4000
#


import json
import logging
import sys

from math import pow
from optparse import OptionParser

from solidfire.factory import ElementFactory



def process_options():
    """Pretty much boilerplate for all of our scripts.  Not much interesting
    just some monotony parsing out command line options and finally
    instantiating a cluster object.
    """
    config = {}
    usage = "usage: %prog [options]\nList Volumes that match name pattern"
    parser = OptionParser(usage, version='%prog 1.0')

    parser.add_option('-C', '--ClusterConfigFile', action='store',
                      type='string',
                      default=None,
                      dest='json_config',
                      help='JSON formatted cluster config, used'
                      ' to specify a SolidFire Cluster other than the default '
                      ' set up in the SolidFireAPI object',)

    parser.add_option('-p', '--pattern', action='store',
                      type='string',
                      default=None,
                      dest='patternStr',
                      help='Enter volume pattern to search for',)

    parser.add_option('-m', '--min', action='store',
                      type='string',
                      default='100',
                      dest='qosMin',
                      help='Enter QOS minimum value',)

    parser.add_option('-x', '--max', action='store',
                      type='string',
                      default='500',
                      dest='qosMax',
                      help='Enter QOS maximum value',)

    parser.add_option('-b', '--burst', action='store',
                      type='string',
                      default='1000',
                      dest='qosBurst',
                      help='Enter QOS burst value',)


    (options, args) = parser.parse_args()


    if options.json_config is not None:
       config_text = open(options.json_config, 'r').read()
       config = json.loads(config_text)

    if config:
       print("\n\n")
       print("MVIP: {mvip}" .format(**config))
       print("\n")
       print("User: {login}" .format(**config))
       print("\n")
       print("Password: {password}" .format(**config))
       print("\n\n")

       cluster_object = ElementFactory.create(config['mvip'],config['login'],config['password'])
    else:
        cluster_object = ElementFactory.create("10.61.97.130","admin","cpoc2217")
    return (cluster_object, options)
#
#  End of Function process_options




if __name__ == "__main__":

  if len(sys.argv) == 1:
     sys.argv.append('-h')

(SFC, options) = process_options()


listof = SFC.list_volumes()
#print(listof)

for volinfo in listof.volumes:
    strVol = volinfo.name
    if strVol.find(options.patternStr) != -1:
      print(volinfo.name)


      kwargs = {'volume_id': volinfo.volume_id,
                'qos': {'minIOPS': options.qosMin,
                        'maxIOPS': options.qosMax,
                        'burstIOPS': options.qosBurst}}


      mod_result = SFC.modify_volume(**kwargs)



