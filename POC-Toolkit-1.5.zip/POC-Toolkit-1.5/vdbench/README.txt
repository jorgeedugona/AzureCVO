README for vdbench files

What's in here and where to start..

Each subdirectory contains the Vdbench configuration files for a particular
environment: FCP (with RDM luns), VMDK (for NFS or FCP datastores), NFS (direct
mount to NFS volumes), and WIN (luns mapped to Windows hosts).


How to use:

	1. Copy these files to a directory on each load generator instance.

	2. Download and copy the Vdbench software into the same directory.

	3. Set up the AFF system with test LUNs and map to the load
	    generators.

	4. As needed, modify the aff-luns-* and aff-hosts include files
	    to reflect the load generator host and LUN configurations.

	5. Either run fill and benchmark scripts individually, or use the
	    "runall" bash script (see below).


Descriptions of files in this directory:

. Files starting with a two-digit number, e.g. 00-aff-basic_tests:
   These are a set of standard modeled workload categories, most based on
   input from NetApp Workload Engineering.  The included files have been
   tuned to create latency curves passing through 1 ms when run on AFF
   8060 and AFF 8080 systems.

   NOTE: AFF 8020 and 8040 systems in many cases will need to use a lower
   thread count in the run definitions (lines starting with rd=), to
   scale the load levels for their performance capabilities.

   Variations are included in many files for additional data points, e.g.
   Oracle 90/10 and 80/20 R/W mixes. Any can be run individually, or as a
   full set using the "runall" script.

. runall: Example bash script that first optionally initializes raw devices,
   then runs all the numbered benchmarks in order. Results
   are placed in a subdirectory with name of the form
   aff-results-<date>-<time>, one folder per numbered test category.

. aff-hosts-*: File included in all vdbench runs that defines the load
   generator Linux instances.  The example file has six instances, 
   corresponding to the lab test configuration.

. aff-luns-*: Files included by all benchmarks, reflecting the storage LUN
   configuration.  Most use the "aff-luns" file so the benchmark
   writes to all the LUNs.
   
. aff-init-luns-*: Vdbench workload called by runall, or that can be run
   by itself to initialize raw devices by performing a sequential write.

   NOTE: If using physical Linux load generator hosts, multipathing will
   require different device path names, e.g. /dev/sdb may need to instead
   be /dev/dm-0.

. vdbench-parser: Excel workbook with macros to automatically parse and graph
   the flatfile.html output of a benchmark run.


