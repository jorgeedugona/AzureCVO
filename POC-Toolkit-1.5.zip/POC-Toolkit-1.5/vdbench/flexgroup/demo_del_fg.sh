
ssh -l admin 10.61.109.100 "set diag;vol unmount -volume fgdemo -vserver nas1 -force true"

ssh -l admin 10.61.109.100 "set diag;vol offline -volume fgdemo -vserver nas1 -force true -foreground true"

ssh -l admin 10.61.109.100 "set diag;vol del -volume fgdemo -vserver nas1 -force true -foreground true"

