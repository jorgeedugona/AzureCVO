
ssh -l admin 10.61.109.100 "vol create -volume fgdemo -aggr-list aggr1,aggr2 -aggr-list-multiplier 8 -size 50t -junction-path /fgdemo -space-guarantee none"


# optional - enable efficiencies on volume

#ssh -l admin 10.61.109.100 "vol eff on -volume fgdemo"

#ssh -l admin 10.61.109.100 "vol eff mod -volume fgdemo -compression true -inline-compression true"


# example of how to expand fg
#ssh -l admin 10.61.109.100 "vol expand -volume fgdemo -aggr-list aggr1,aggr2 -aggr-list-multiplier 2"
